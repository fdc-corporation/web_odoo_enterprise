# -*- coding: utf-8 -*-
# from odoo import http


# class WebEnterpriseFan(http.Controller):
#     @http.route('/web_enterprise_fan/web_enterprise_fan/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/web_enterprise_fan/web_enterprise_fan/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('web_enterprise_fan.listing', {
#             'root': '/web_enterprise_fan/web_enterprise_fan',
#             'objects': http.request.env['web_enterprise_fan.web_enterprise_fan'].search([]),
#         })

#     @http.route('/web_enterprise_fan/web_enterprise_fan/objects/<model("web_enterprise_fan.web_enterprise_fan"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('web_enterprise_fan.object', {
#             'object': obj
#         })
