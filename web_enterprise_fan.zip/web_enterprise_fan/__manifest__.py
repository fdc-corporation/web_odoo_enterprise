# -*- coding: utf-8 -*-
{
    'name': "web_enterprise_fan",

    'summary': """
        Odoo crack""",

    'description': """
        Crack odoo v17
    """,

    'author': "Uncategorized",
    'website': "http://www.Uncategorized.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',
    'license': 'OEEL-1',

    # any module necessary for this one to work correctly
    'depends': ['web_enterprise'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        'views/templates.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'web_enterprise_fan/static/src/webclient/**/*.xml',
        ],
    }
}
